package com.example.shoppinglist.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.shoppinglist.R
import com.example.shoppinglist.data.ShopList
import kotlinx.android.synthetic.main.list_row.view.*


class ListAdapter : RecyclerView.Adapter<ListAdapter.ViewHolder>{

    var listItems = mutableListOf<ShopList>(
    ShopList("tej",200,0,"",true,"Huf")
    )

    val context: Context
    constructor(context: Context):super() {
        this.context = context
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val listView = LayoutInflater.from(context).inflate(R.layout.list_row, parent,false)
        return ViewHolder(listView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val listItem = listItems[position]
        var categorysrc =R.drawable.ic_launcher

        when(listItem.category){
            0 -> categorysrc= R.drawable.food
            1 -> categorysrc= R.drawable.electric
            2 -> categorysrc= R.drawable.book
            3 -> categorysrc= R.drawable.clothes
        }
        holder.tvName.text = listItem.name
        holder.tvPrice.text = listItem.price.toString()
        holder.tvCategory.setImageResource(categorysrc)
        holder.tvDetails.text = listItem.details



    }

    override fun getItemCount(): Int {
        return listItems.size
    }

    fun addList(list: ShopList){
        listItems.add(list)
        notifyItemInserted(listItems.lastIndex)

    }

    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        var tvName = itemView.tvName
        var tvPrice = itemView.tvPrice
        var tvCategory = itemView.imageCategory
        var tvDetails = itemView.tvDetails
    }


}