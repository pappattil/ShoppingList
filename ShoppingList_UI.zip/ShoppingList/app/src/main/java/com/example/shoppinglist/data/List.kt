package com.example.shoppinglist.data

data class ShopList(
        var name: String,
        var price: Int,
        var category: Int,
        var details: String,
        var status: Boolean,
        var currency: String


)
